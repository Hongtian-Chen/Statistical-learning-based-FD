%% first part: Stack original data
s_p=3;
Length=4e5;
t_begin=20;
s_f=1;
U_p=stacked(U,s_p,Length,t_begin);
Y_p=stacked(Y,s_p,Length,t_begin);
U_f=stacked(U,s_f,Length,t_begin+s_p);
Y_f=stacked(Y,s_f,Length,t_begin+s_p);

Cube=[U_p;Y_p;U_f];
Cube_out=Y_f;

%% or second part: Stack faulty data

s_p=3;
Length=1e4;
t_begin=5;
s_f=1;
U_p_faulty=stacked(U_faulty,s_p,Length,t_begin);
Y_p_faulty=stacked(Y_faulty,s_p,Length,t_begin);
U_f_faulty=stacked(U_faulty,s_f,Length,t_begin+s_p);
Y_f_faulty=stacked(Y_faulty,s_f,Length,t_begin+s_p);

Cube_faulty=[U_p_faulty;Y_p_faulty;U_f_faulty];
Cube_out_faulty=Y_f_faulty;

