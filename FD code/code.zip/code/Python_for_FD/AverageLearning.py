#!/usr/bin/env python
# coding: utf-8

import numpy as np
import matplotlib.pyplot as plt
from AverageLearning import *

def Compute_Cubes(NUM_SAMPLES, INPUT_DIM):
    NUM_CUBES = int(NUM_SAMPLES**(1/3))
    NUM_SEG = int(NUM_CUBES**(1/INPUT_DIM))
    NUM_CUBES = NUM_SEG ** INPUT_DIM
    return NUM_CUBES, NUM_SEG


class AveragingMethod:
    
    def __init__(self, input_dim, num_seg):
        self.input_dim = input_dim
        self.num_seg = num_seg
        
    @staticmethod
    def Get_Boundries(input_data):
        up = np.max(input_data, axis=1)
        down = np.min(input_data, axis=1)
        return np.stack((down, up))
    
    def Split_Segment(self):
        self.interval_length = (self.boundries[1] - self.boundries[0])/(self.num_seg)
        self.intervals = np.zeros((self.num_seg+1, self.boundries.shape[1]))
        for i in range(self.num_seg):
            self.intervals[i] = self.boundries[0] + self.interval_length * i
        self.intervals[-1] = self.boundries[1]
        
    def Match_Intervals(self, input_data):
        ls = [np.searchsorted(self.intervals[:,i], input_data[i], side='right') - 1 for i in range(self.intervals.shape[1])]
        locations = np.stack(ls)
        locations[locations < 0] = 0
        locations[locations >= self.num_seg] = self.num_seg - 1
        
        return locations

        
    def Train(self, input_data, values):
        
        self.boundries = self.Get_Boundries(input_data)
        self.Split_Segment()
        
        size = [self.num_seg] * self.input_dim
        self.output = np.zeros(size)
        self.samples_per_cube = np.zeros(size)
        
        locations = self.Match_Intervals(input_data)
        
        unique_locations, inverse_indices = np.unique(locations, return_inverse=True, axis=1)
        
        for i in range(unique_locations.shape[1]):
            location = unique_locations[:, i]
            indices = np.where(inverse_indices == i)[0]
            count = indices.shape[0]
            self.output[tuple(location)] = np.sum(values[indices]) / count
            self.samples_per_cube[tuple(location)] = count
            
        
    def Inference(self, input_data):
        locations = self.Match_Intervals(input_data)
        values = np.zeros(input_data.shape[1])
        unique_locations, inverse_indices = np.unique(locations, return_inverse=True, axis=1)
        for i in range(unique_locations.shape[1]):
            location = unique_locations[:, i]
            indices = np.where(inverse_indices == i)[0]
            values[indices] = self.output[tuple(location)]
        
        return values




